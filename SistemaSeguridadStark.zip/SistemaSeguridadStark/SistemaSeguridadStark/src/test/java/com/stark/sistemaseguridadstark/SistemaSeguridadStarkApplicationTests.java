package com.stark.sistemaseguridadstark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaSeguridadStarkApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.stark.sistemaseguridadstark.servicio;

import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Random;

@Component
public class MovementSensorSimulator {
    private final SensorProcessingService processor;
    private final Random rnd = new Random();

    public MovementSensorSimulator(SensorProcessingService processor) { this.processor = processor; }

    @Scheduled(fixedRate = 3000)
    public void tick() {
        SensorEvent e = new SensorEvent();
        e.setSensorId("mov-" + rnd.nextInt(5));
        e.setType("MOTION");
        e.setPayload("Movimiento");
        e.setSeverity(rnd.nextInt(100) > 85 ? "CRITICAL" : "INFO");
        e.setTimestamp(Instant.now());
        processor.processEvent(e);
    }
}

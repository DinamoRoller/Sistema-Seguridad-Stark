package com.stark.sistemaseguridadstark.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.stark.sistemaseguridadstark.modelo.SensorEvent;

import java.time.Instant;
import java.util.List;

public interface SensorEventRepository extends JpaRepository<SensorEvent, Long> {

    @Query("select e.type, count(e) from SensorEvent e group by e.type")
    List<Object[]> countGroupedByType();

    long countByTimestampAfter(Instant since);

    List<SensorEvent> findTop200ByOrderByTimestampDesc();

    List<SensorEvent> findByTimestampAfterOrderByTimestampAsc(Instant since);
}

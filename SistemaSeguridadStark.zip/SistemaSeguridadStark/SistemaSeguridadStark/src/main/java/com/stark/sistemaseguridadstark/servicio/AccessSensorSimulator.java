package com.stark.sistemaseguridadstark.servicio;

import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Random;

@Component
public class AccessSensorSimulator {
    private final SensorProcessingService processor;
    private final Random rnd = new Random();

    public AccessSensorSimulator(SensorProcessingService processor) { this.processor = processor; }

    @Scheduled(fixedRate = 5000)
    public void tick() {
        SensorEvent e = new SensorEvent();
        e.setSensorId("acc-" + rnd.nextInt(3));
        e.setType("ACCESS");
        e.setPayload(rnd.nextBoolean() ? "Badge OK" : "Badge FAIL");
        e.setSeverity(e.getPayload().contains("FAIL") ? "CRITICAL" : "INFO");
        e.setTimestamp(Instant.now());
        processor.processEvent(e);
    }
}

package com.stark.sistemaseguridadstark.servicio;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.stark.sistemaseguridadstark.modelo.SensorEvent;

import java.time.Instant;
import java.util.Random;

@Service
public class SensorSimulatorService {

    private final SensorProcessingService processor;
    private final Random rnd = new Random();

    public SensorSimulatorService(SensorProcessingService processor) {
        this.processor = processor;
    }

    @Scheduled(fixedRate = 3000) // cada 5 segundos
        public void tick() {
            SensorEvent e = new SensorEvent();
            e.setSensorId("mov-" + rnd.nextInt(5));
            e.setType("MOTION");
            e.setPayload("Movimiento");
            e.setSeverity(rnd.nextInt(100) > 85 ? "CRITICAL" : "INFO");
            e.setTimestamp(Instant.now());
            processor.processEvent(e);
        }
}

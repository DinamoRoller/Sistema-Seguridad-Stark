package com.stark.sistemaseguridadstark.servicio;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import com.stark.sistemaseguridadstark.repositorio.SensorEventRepository;

@Service
public class SensorProcessingService {

    private final SensorEventRepository repo;
    private final NotificationService notifier;
    private final Timer processingTimer;

    public SensorProcessingService(SensorEventRepository repo, NotificationService notifier, MeterRegistry registry) {
        this.repo = repo;
        this.notifier = notifier;
        this.processingTimer = registry.timer("stark.processing.time");
    }

    @Async("sensorProcessorExecutor")
    public void processEvent(SensorEvent event) {
        processingTimer.record(() -> {
            repo.save(event);
            if ("CRITICAL".equalsIgnoreCase(event.getSeverity())) {
                notifier.sendAlert(event);
            }
        });
    }
}

package com.stark.sistemaseguridadstark.servicio;

import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Random;

@Component
public class TemperatureSensorSimulator {
    private final SensorProcessingService processor;
    private final Random rnd = new Random();

    public TemperatureSensorSimulator(SensorProcessingService processor) { this.processor = processor; }

    @Scheduled(fixedRate = 7000)
    public void tick() {
        int t = 18 + rnd.nextInt(20); // 18-37 ºC
        SensorEvent e = new SensorEvent();
        e.setSensorId("tmp-" + rnd.nextInt(2));
        e.setType("TEMPERATURE");
        e.setPayload(t + "C");
        e.setSeverity((t < 19 || t > 30) ? "CRITICAL" : "INFO");
        e.setTimestamp(Instant.now());
        processor.processEvent(e);
    }
}

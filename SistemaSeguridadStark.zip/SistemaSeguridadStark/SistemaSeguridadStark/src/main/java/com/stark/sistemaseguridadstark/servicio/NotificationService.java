package com.stark.sistemaseguridadstark.servicio;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import com.stark.sistemaseguridadstark.modelo.SensorEvent;

@Service
public class NotificationService {

    private final SimpMessagingTemplate template;
    private final ObjectProvider<EmailChannel> email;

    public NotificationService(SimpMessagingTemplate template, ObjectProvider<EmailChannel> email) {
        this.template = template;
        this.email = email;
    }

    public void sendAlert(SensorEvent event) {
        template.convertAndSend("/topic/alerts", event);
        EmailChannel mail = email.getIfAvailable();
        if (mail != null) mail.send(event);
    }
}

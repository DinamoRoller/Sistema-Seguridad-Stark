package com.stark.sistemaseguridadstark.controlador;

import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.List;
import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import com.stark.sistemaseguridadstark.repositorio.SensorEventRepository;
import com.stark.sistemaseguridadstark.servicio.SensorProcessingService;

@RestController
@RequestMapping("/api/sensors")
public class SensorController {

    private final SensorEventRepository repo;
    private final SensorProcessingService processor;

    public SensorController(SensorEventRepository repo, SensorProcessingService processor) {
        this.repo = repo;
        this.processor = processor;
    }

    @PostMapping("/event")
    public SensorEvent receiveEvent(@RequestBody SensorEvent event) {
        event.setTimestamp(Instant.now());
        processor.processEvent(event);
        return event;
    }

    @GetMapping("/events")
    public List<SensorEvent> getEvents() {
        return repo.findAll();
    }
}

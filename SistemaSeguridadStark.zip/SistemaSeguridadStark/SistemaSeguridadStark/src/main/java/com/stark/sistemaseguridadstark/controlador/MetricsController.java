package com.stark.sistemaseguridadstark.controlador;

import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import com.stark.sistemaseguridadstark.repositorio.SensorEventRepository;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/metrics")
public class MetricsController {

    private final SensorEventRepository repo;
    public MetricsController(SensorEventRepository repo) { this.repo = repo; }

    @GetMapping("/events-by-type")
    public Map<String, Long> eventsByType() {
        Map<String, Long> out = new LinkedHashMap<>();
        for (Object[] row : repo.countGroupedByType()) {
            out.put(String.valueOf(row[0]), (Long) row[1]);
        }
        return out;
    }

    @GetMapping("/recent-events")
    public List<SensorEvent> recent(@RequestParam(defaultValue = "120") int seconds) {
        return repo.findByTimestampAfterOrderByTimestampAsc(Instant.now().minusSeconds(seconds));
    }

    @GetMapping("/throughput")
    public Map<String, Object> throughput(@RequestParam(defaultValue = "60") int windowSeconds) {
        long count = repo.countByTimestampAfter(Instant.now().minusSeconds(windowSeconds));
        return Map.of("windowSeconds", windowSeconds, "count", count);
    }
}

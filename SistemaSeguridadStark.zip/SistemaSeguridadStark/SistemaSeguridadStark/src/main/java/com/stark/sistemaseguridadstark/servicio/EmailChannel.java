package com.stark.sistemaseguridadstark.servicio;

import com.stark.sistemaseguridadstark.modelo.SensorEvent;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "mail.alerts", name = "enabled", havingValue = "true")
public class EmailChannel {

    private final JavaMailSender mailSender;

    public EmailChannel(JavaMailSender mailSender) { this.mailSender = mailSender; }

    public void send(SensorEvent e) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(System.getProperty("ALERT_EMAIL", "ops@example.com"));
        msg.setSubject("[ALERTA] " + e.getType() + " - " + e.getSeverity());
        msg.setText("Sensor " + e.getSensorId() + " -> " + e.getPayload() + " @ " + e.getTimestamp());
        mailSender.send(msg);
    }
}
